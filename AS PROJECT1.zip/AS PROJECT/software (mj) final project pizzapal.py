import tkinter as tk
from tkinter import messagebox, ttk
import re

class PizzaPalApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("PizzaPal")
        self.geometry("600x400")

        # Create a notebook
        self.notebook = ttk.Notebook(self)
        self.notebook.pack(fill=tk.BOTH, expand=True)

        # Create the main menu page
        self.main_menu_page = MainMenuPage(self.notebook, self)
        self.notebook.add(self.main_menu_page, text="Main Menu")

        # Create the select size and crust page
        self.select_size_page = SelectSizePage(self.notebook, self)
        self.notebook.add(self.select_size_page, text="Select Size & Crust")

        # Create the select toppings page
        self.select_toppings_page = SelectToppingsPage(self.notebook, self)
        self.notebook.add(self.select_toppings_page, text="Select Toppings")

        # Create the customer information page
        self.customer_info_page = CustomerInfoPage(self.notebook, self.select_size_page, self.select_toppings_page, self)
        self.notebook.add(self.customer_info_page, text="Customer Info")

        # Create the receipt page
        self.receipt_page = ReceiptPage(self.notebook, self)
        self.notebook.add(self.receipt_page, text="Receipt")

        # Create the clock page
        self.clock_page = ClockPage(self.notebook, self)
        self.notebook.add(self.clock_page, text="Remaining Time")

        # Initially, show the main menu page
        self.notebook.select(self.main_menu_page)

    def show_select_size_page(self):
        self.notebook.select(self.select_size_page)

    def show_select_toppings_page(self):
        self.notebook.select(self.select_toppings_page)

    def show_customer_info_page(self):
        self.customer_info_page.calculate_price()
        self.notebook.select(self.customer_info_page)

    def show_receipt_page(self, receipt_text):  
        self.receipt_page.update_receipt(receipt_text)
        self.notebook.select(self.receipt_page)

    def show_clock_page(self):
        self.notebook.select(self.clock_page)

    def show_previous_page(self):
        current_index = self.notebook.index("current")
        if current_index > 0:
            self.notebook.select(current_index - 1)

    def exit_application(self):
        self.destroy()

class MainMenuPage(tk.Frame):
    def __init__(self, parent, app):
        super().__init__(parent)

        self.app = app

        self.welcome_label = tk.Label(self, text="Welcome to PizzaPal!", font=("Arial", 18))
        self.welcome_label.pack(pady=20)

        self.new_order_button = tk.Button(self, text="Start New Order", command=self.app.show_select_size_page)
        self.new_order_button.pack(pady=10)

        self.exit_button = tk.Button(self, text="Exit", command=self.app.exit_application)
        self.exit_button.pack(pady=10)

class SelectSizePage(tk.Frame):
    def __init__(self, parent, app):
        super().__init__(parent)

        self.app = app

        self.size_label = tk.Label(self, text="Select Pizza Size:", font=("Arial", 12))
        self.size_label.grid(row=0, column=0, padx=10, pady=10, sticky="w")

        self.size_prices = {"Small": 10.99, "Medium": 12.99, "Large": 14.99}

        self.selected_size = tk.StringVar(value="Small")
        for i, (size, price) in enumerate(self.size_prices.items(), start=1):
            size_button = tk.Radiobutton(self, text=f"{size} (${price:.2f})", variable=self.selected_size, value=size)
            size_button.grid(row=i, column=0, padx=10, pady=5, sticky="w")

        self.crust_label = tk.Label(self, text="Select Crust Type:", font=("Arial", 12))
        self.crust_label.grid(row=len(self.size_prices) + 1, column=0, padx=10, pady=10, sticky="w")

        self.crust_types = ["Thin Crust", "Thick Crust", "Stuffed Crust"]
        self.selected_crust = tk.StringVar(value="Thin Crust")
        for i, crust_type in enumerate(self.crust_types, start=len(self.size_prices) + 2):
            crust_button = tk.Radiobutton(self, text=crust_type, variable=self.selected_crust, value=crust_type)
            crust_button.grid(row=i, column=0, padx=10, pady=5, sticky="w")

        self.next_button = tk.Button(self, text="Next", command=self.app.show_select_toppings_page)
        self.next_button.grid(row=len(self.size_prices) + len(self.crust_types) + 3, column=0, pady=10)

        self.back_button = tk.Button(self, text="Back", command=self.app.show_previous_page)
        self.back_button.grid(row=len(self.size_prices) + len(self.crust_types) + 4, column=0, pady=10)

class SelectToppingsPage(tk.Frame):
    def __init__(self, parent, app):
        super().__init__(parent)

        self.app = app

        self.toppings_label = tk.Label(self, text="Select Toppings:", font=("Arial", 12))
        self.toppings_label.grid(row=0, column=0, padx=10, pady=10, sticky="w")

        self.toppings_prices = {"Pepperoni": 0.50, "Mushrooms": 0.50, "Extra Cheese": 0.50, "Chicken": 0.50,
                                "Olive": 0.50, "Green Pepper": 0.50, "Onion": 0.50, "Tomato": 0.50}

        self.selected_toppings = {}
        row_counter = 1
        for topping, price in self.toppings_prices.items():
            topping_var = tk.BooleanVar(value=False)
            self.selected_toppings[topping] = topping_var
            topping_cb = tk.Checkbutton(self, text=f"{topping} (+${price:.2f})", variable=topping_var)
            topping_cb.grid(row=row_counter, column=0, padx=10, pady=5, sticky="w")
            row_counter += 1

        self.next_button = tk.Button(self, text="Next", command=self.app.show_customer_info_page)
        self.next_button.grid(row=row_counter, column=0, pady=10)

        self.back_button = tk.Button(self, text="Back", command=self.app.show_previous_page)
        self.back_button.grid(row=row_counter + 1, column=0, pady=10)

class CustomerInfoPage(tk.Frame):
    def __init__(self, parent, select_size_page, select_toppings_page, app):
        super().__init__(parent)

        self.app = app
        self.select_size_page = select_size_page
        self.select_toppings_page = select_toppings_page

        self.size_prices = {"Small": 10.99, "Medium": 12.99, "Large": 14.99}
        self.toppings_prices = {"Pepperoni": 0.50, "Mushrooms": 0.50, "Extra Cheese": 0.50, "Chicken": 0.50,
                                "Olive": 0.50, "Green Pepper": 0.50, "Onion": 0.50, "Tomato": 0.50}

        self.total_price_label = tk.Label(self, text="Total Price:", font=("Arial", 12))
        self.total_price_label.grid(row=0, column=0, padx=10, pady=5, sticky="w")

        self.order_name_label = tk.Label(self, text="Order Name:")
        self.order_name_label.grid(row=1, column=0, padx=10, pady=5, sticky="w")
        self.order_name_entry = tk.Entry(self)
        self.order_name_entry.grid(row=1, column=1, padx=10, pady=5, sticky="w")

        self.card_number_label = tk.Label(self, text="Card Number (16 digits):")
        self.card_number_label.grid(row=2, column=0, padx=10, pady=5, sticky="w")
        self.card_number_entry = tk.Entry(self)
        self.card_number_entry.grid(row=2, column=1, padx=10, pady=5, sticky="w")

        self.cvv_label = tk.Label(self, text="CVV (3 digits):")
        self.cvv_label.grid(row=3, column=0, padx=10, pady=5, sticky="w")
        self.cvv_entry = tk.Entry(self)
        self.cvv_entry.grid(row=3, column=1, padx=10, pady=5, sticky="w")

        self.expiration_label = tk.Label(self, text="Expiration Date (MM/YY):")
        self.expiration_label.grid(row=4, column=0, padx=10, pady=5, sticky="w")
        self.expiration_entry = tk.Entry(self)
        self.expiration_entry.grid(row=4, column=1, padx=10, pady=5, sticky="w")

        self.confirm_button = tk.Button(self, text="Confirm Order", command=self.confirm_order)
        self.confirm_button.grid(row=5, column=0, padx=10, pady=10)

        self.remaining_time_button = tk.Button(self, text="Remaining Time", command=self.app.show_clock_page)
        self.remaining_time_button.grid(row=5, column=1, padx=10, pady=10)

        self.back_button = tk.Button(self, text="Back", command=self.app.show_previous_page)
        self.back_button.grid(row=5, column=2, padx=10, pady=10)

    def calculate_price(self):
        total_price = 0
        for size, price in self.size_prices.items():
            if size == self.select_size_page.selected_size.get():
                total_price += price
                break
        for topping, var in self.select_toppings_page.selected_toppings.items():
            if var.get():
                total_price += self.toppings_prices[topping]
        self.total_price_label.config(text=f"Total Price: ${total_price:.2f}")

    def confirm_order(self):
        order_name = self.order_name_entry.get()
        card_number = self.card_number_entry.get()
        cvv = self.cvv_entry.get()
        expiration_date = self.expiration_entry.get()

        if not re.match(r"^\d{16}$", card_number):
            messagebox.showerror("Error", "Card number must be 16 digits")
            return
        if not re.match(r"^\d{3}$", cvv):
            messagebox.showerror("Error", "CVV must be 3 digits")
            return
        if not re.match(r"^(0[1-9]|1[0-2])/\d{2}$", expiration_date):
            messagebox.showerror("Error", "Invalid expiration date. Format must be MM/YY")
            return

        order_details = f"Order Name: {order_name}\n"
        order_details += f"Pizza Size: {self.select_size_page.selected_size.get()}\n"
        order_details += "Toppings:\n"
        for topping, var in self.select_toppings_page.selected_toppings.items():
            if var.get():
                order_details += f"- {topping}\n"
        order_details += f"Total Price: {self.total_price_label.cget('text')}"

        self.app.show_receipt_page(order_details)

class ReceiptPage(tk.Frame):
    def __init__(self, parent, app):
        super().__init__(parent)

        self.app = app

        self.receipt_text = tk.Text(self, height=20, width=50)
        self.receipt_text.pack(padx=10, pady=10)

    def update_receipt(self, text):
        self.receipt_text.delete("1.0", tk.END)
        self.receipt_text.insert(tk.END, text)

class ClockPage(tk.Frame):
    def __init__(self, parent, app):
        super().__init__(parent)

        self.app = app

        self.remaining_time_label = tk.Label(self, text="Order will be ready in:", font=("Arial", 18))
        self.remaining_time_label.pack(padx=10, pady=10)

        self.clock_label = tk.Label(self, text="30:00", font=("Arial", 24), fg="green")
        self.clock_label.pack(padx=10, pady=10)

        self.back_button = tk.Button(self, text="Back", command=self.app.show_previous_page)
        self.back_button.pack(pady=10)

        self.remaining_time = 1800  
        self.start_clock()

    def start_clock(self):
        remaining_time = 1800  
        self.update_clock(remaining_time)

    def update_clock(self, remaining_time):
        if remaining_time >= 0:
            minutes = remaining_time // 60
            seconds = remaining_time % 60
            time_str = f"{minutes:02d}:{seconds:02d}"
            self.clock_label.config(text=time_str)
            remaining_time -= 1
            self.after(1000, self.update_clock, remaining_time)  
        else:
            self.clock_label.config(text="Order is ready!")

if __name__ == "__main__":
    app = PizzaPalApp()
    app.mainloop()
